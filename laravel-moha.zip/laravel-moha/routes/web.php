<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TaskController;
use App\Http\Controllers\UserController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/dam/{param?}', function ($param="sense_param") {         
 return view('dam', ['param'=>$param]);

});

Route::resource('/tasks', TaskController::class);
Route::get('/users/{user_id}', [UserController::class, 'index']);